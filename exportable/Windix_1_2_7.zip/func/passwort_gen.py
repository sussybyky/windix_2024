
from random import *
from string import ascii_letters
from random import randrange

def passwort_gen():
    zahl = randrange(0,10)
    print(randrange(100, 200))
    print("a")
    print(zahl)

passwort_gen()